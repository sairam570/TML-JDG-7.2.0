package com.tml.AIP_VOR_JDG_TRANS.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties("jdg")
public class JdgProperties {
	
	/*private String hostname;
	private String port;
    private long latitude;
    private long longitude;
    private String div_name;
    private String x_prefer_partner_id;
    private String par_row_id;
    private String partner_name;
    
    public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public long getLatitude() {
		return latitude;
	}
	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}
	public long getLongitude() {
		return longitude;
	}
	public void setLongitude(long longitude) {
		this.longitude = longitude;
	}
	public String getDiv_name() {
		return div_name;
	}
	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}
	public String getX_prefer_partner_id() {
		return x_prefer_partner_id;
	}
	public void setX_prefer_partner_id(String x_prefer_partner_id) {
		this.x_prefer_partner_id = x_prefer_partner_id;
	}
	public String getPar_row_id() {
		return par_row_id;
	}
	public void setPar_row_id(String par_row_id) {
		this.par_row_id = par_row_id;
	}
	public String getPartner_name() {
		return partner_name;
	}
	public void setPartner_name(String partner_name) {
		this.partner_name = partner_name;
	}*/
	
	 private String hostname;
	    private String port;
	    private String selectAccountData;
	    private int totalDays;
	    private int totalValue;

	    public int getTotalDays() {
	        return totalDays;
	    }

	    public void setTotalDays(int totalDays) {
	        this.totalDays = totalDays;
	    }

	    public int getTotalValue() {
	        return totalValue;
	    }

	    public void setTotalValue(int totalValue) {
	        this.totalValue = totalValue;
	    }


	    public String getSelectAccountData() {
	        return selectAccountData;
	    }

	    public void setSelectAccountData(String selectAccountData) {
	        this.selectAccountData = selectAccountData;
	    }

	    public String getHostname() {
	        return hostname;
	    }

	    public void setHostname(String hostname) {
	        this.hostname = hostname;
	    }

	    public String getPort() {
	        return port;
	    }

	    public void setPort(String port) {
	        this.port = port;
	    }
}
