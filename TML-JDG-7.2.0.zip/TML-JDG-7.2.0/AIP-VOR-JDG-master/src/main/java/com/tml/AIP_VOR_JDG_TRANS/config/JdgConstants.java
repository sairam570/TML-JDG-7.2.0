package com.tml.AIP_VOR_JDG_TRANS.config;

public interface JdgConstants {
	
	// String CACHE_NAME = "VORCache";
	 String CACHE_NAME = "Sample";

}
