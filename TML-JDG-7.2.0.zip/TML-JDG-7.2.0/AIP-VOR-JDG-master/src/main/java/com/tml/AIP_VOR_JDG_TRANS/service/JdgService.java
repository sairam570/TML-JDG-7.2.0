package com.tml.AIP_VOR_JDG_TRANS.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import java.util.Map;
import java.util.Set;

import com.tml.AIP_VOR_JDG_TRANS.esb.VORUIResponse;

public interface JdgService {
	
	 boolean put(List<VORUIResponse> VORUIResponseList) throws Exception;

	    

	    /*
	     * Put all data of time period
	     */
	    boolean putAll(String OrderId) throws Exception;

	    /*
	     * Get All Account extract Data
	     */
	    List<VORUIResponse> getAll() throws Exception;

	    /*
	     * Update or add value to index map
	     */
	    boolean delete(String OrderId) throws Exception;
	    
	   Set<VORUIResponse> search(HashMap<String, String> paramMap) throws Exception;
	    //Set<VORUIResponse> search(String PAR_ROW_ID) throws Exception;

}
