package com.tml.AIP_VOR_JDG_TRANS;



//@SpringBootTest
class AipVorJdgTransApplicationTests {

	//@Test
	void contextLoads() {
	}

}
